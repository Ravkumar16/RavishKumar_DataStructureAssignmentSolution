package com.greatLearning;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class skyScraper {

	 
	    public static void main(String[] args)
	    {
	        Queue<Integer> q
	            = new LinkedList<>();
	 
	 		Scanner sc= new Scanner(System.in); 
	 		System.out.print("enter the total no of floors in the building");
	 		int floorNo= sc.nextInt();
	        
	        for (int i = 1; i <= floorNo; i++){
	        	System.out.print("enter the floor size given on day : " + i);
	        	int floorsize= sc.nextInt();
	            q.add(floorsize);
	            
	        }

	       
	    
	}

}
